const prerender = true;
const load = () => {
  return {};
};
export {
  load,
  prerender
};
