

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.GvfOxRsk.js","_app/immutable/chunks/DLUjBBE0.js","_app/immutable/chunks/0kQv1Rv8.js","_app/immutable/chunks/DoGcAwn1.js","_app/immutable/chunks/k-dchefe.js","_app/immutable/chunks/BaKfeJtT.js"];
export const stylesheets = [];
export const fonts = [];
