

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.C0Pia_B9.js","_app/immutable/chunks/D6KCxkSC.js","_app/immutable/chunks/Cg5OoOK4.js","_app/immutable/chunks/BpYs9rxi.js","_app/immutable/chunks/zaW237m1.js","_app/immutable/chunks/DTb4XZBJ.js"];
export const stylesheets = [];
export const fonts = [];
