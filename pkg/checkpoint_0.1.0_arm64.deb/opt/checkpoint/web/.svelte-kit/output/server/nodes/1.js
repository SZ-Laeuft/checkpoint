

export const index = 1;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.CpDban6c.js","_app/immutable/chunks/D6KCxkSC.js","_app/immutable/chunks/Cg5OoOK4.js","_app/immutable/chunks/BpYs9rxi.js","_app/immutable/chunks/DUggJcnX.js","_app/immutable/chunks/DTb4XZBJ.js"];
export const stylesheets = [];
export const fonts = [];
