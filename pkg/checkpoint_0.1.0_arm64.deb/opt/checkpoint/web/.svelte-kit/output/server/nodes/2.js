

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.C9AWnuSj.js","_app/immutable/chunks/D6KCxkSC.js","_app/immutable/chunks/Cg5OoOK4.js","_app/immutable/chunks/DTb4XZBJ.js","_app/immutable/chunks/BpYs9rxi.js","_app/immutable/chunks/dUbt8T-O.js","_app/immutable/chunks/D9JygOWw.js"];
export const stylesheets = [];
export const fonts = [];
