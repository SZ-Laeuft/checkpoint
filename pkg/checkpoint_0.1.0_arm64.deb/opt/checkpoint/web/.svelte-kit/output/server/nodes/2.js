

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.CKWGLPWO.js","_app/immutable/chunks/DLUjBBE0.js","_app/immutable/chunks/0kQv1Rv8.js","_app/immutable/chunks/BaKfeJtT.js","_app/immutable/chunks/DoGcAwn1.js","_app/immutable/chunks/CTPheNpA.js","_app/immutable/chunks/CVQBv6SZ.js"];
export const stylesheets = [];
export const fonts = [];
