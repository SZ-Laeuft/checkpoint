export const manifest = (() => {
function __memo(fn) {
	let value;
	return () => value ??= (value = fn());
}

return {
	appDir: "_app",
	appPath: "static/_app",
	assets: new Set(["robots.txt"]),
	mimeTypes: {".txt":"text/plain"},
	_: {
		client: {start:"_app/immutable/entry/start.DvuRFHvt.js",app:"_app/immutable/entry/app.Cj045Hxy.js",imports:["_app/immutable/entry/start.DvuRFHvt.js","_app/immutable/chunks/DoOgWSSe.js","_app/immutable/chunks/Cg5OoOK4.js","_app/immutable/chunks/DTb4XZBJ.js","_app/immutable/entry/app.Cj045Hxy.js","_app/immutable/chunks/Cg5OoOK4.js","_app/immutable/chunks/BpYs9rxi.js","_app/immutable/chunks/D6KCxkSC.js","_app/immutable/chunks/DTb4XZBJ.js","_app/immutable/chunks/dUbt8T-O.js","_app/immutable/chunks/D9JygOWw.js"],stylesheets:[],fonts:[],uses_env_dynamic_public:false},
		nodes: [
			__memo(() => import('./nodes/0.js')),
			__memo(() => import('./nodes/1.js')),
			__memo(() => import('./nodes/2.js'))
		],
		remotes: {
			
		},
		routes: [
			{
				id: "/",
				pattern: /^\/$/,
				params: [],
				page: { layouts: [0,], errors: [1,], leaf: 2 },
				endpoint: null
			}
		],
		prerendered_routes: new Set([]),
		matchers: async () => {
			
			return {  };
		},
		server_assets: {}
	}
}
})();
