import { a2 as attr_class, e as escape_html, a3 as stringify } from "../../chunks/index.js";
function _page($$renderer, $$props) {
  $$renderer.component(($$renderer2) => {
    let time = /* @__PURE__ */ new Date();
    function formatTime(date) {
      return pad(date.getHours()) + ":" + pad(date.getMinutes()) + ":" + pad(date.getSeconds());
    }
    function pad(num) {
      return num.toString().padStart(2, "0");
    }
    $$renderer2.push(`<div${attr_class(`absolute top-0 right-0 m-1 text-[0.4em] ${stringify("text-black")}`)}>${escape_html(
      null
    )} ${escape_html(formatTime(time))}</div> <main class="flex items-center content-evenly justify-center w-full h-screen">`);
    {
      $$renderer2.push("<!--[0-->");
      $$renderer2.push(`<p class="text-center">Bereit zum Scannen!</p>`);
    }
    $$renderer2.push(`<!--]--></main>`);
  });
}
export {
  _page as default
};
