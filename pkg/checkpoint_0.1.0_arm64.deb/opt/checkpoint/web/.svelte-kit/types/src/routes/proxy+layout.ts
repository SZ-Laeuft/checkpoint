// @ts-nocheck
import type {LayoutLoad} from './$types';
export const prerender = true
export const load = () => {
    return {};
};;null as any as LayoutLoad;