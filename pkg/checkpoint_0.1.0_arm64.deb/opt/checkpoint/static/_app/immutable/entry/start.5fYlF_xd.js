import{l as o,a as r}from"../chunks/DLmCZp-_.js";export{o as load_css,r as start};
